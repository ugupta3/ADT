package net.viralpatel.android.speechtotextdemo;

import java.util.ArrayList;
import java.util.Locale;

import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.speech.RecognizerIntent;
import android.speech.tts.TextToSpeech;
import android.util.Log;
import android.view.Menu;
import android.view.View;
import android.view.ViewGroup.LayoutParams;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.memetix.mst.language.Language;
import com.memetix.mst.translate.Translate;

public class MainActivity extends Activity implements
		TextToSpeech.OnInitListener {

	protected static final int REQUEST_OK = 1;
	private ImageButton btnSpeaklngOne;
	private ImageButton btnSpeaklngTwo;

	private TextToSpeech textToSpeech;

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		textToSpeech = new TextToSpeech(this, this);

		btnSpeaklngOne = (ImageButton) findViewById(R.id.spklngButton1);
		btnSpeaklngOne.setOnClickListener(new View.OnClickListener() {

			@Override
			public void onClick(View v) {

				Intent intent = new Intent(
						RecognizerIntent.ACTION_RECOGNIZE_SPEECH);

				intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, "en-US");
				try {
					startActivityForResult(intent, REQUEST_OK);
					} catch (ActivityNotFoundException a) {
					Toast t = Toast.makeText(getApplicationContext(),
							"Opps! Your device doesn't support Speech to Text",
							Toast.LENGTH_SHORT);
					t.show();
					try {
						addChatItem("I am Sorry", Language.ENGLISH,
								Language.SPANISH);
					} catch (Exception e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}
				
			}
		});

		btnSpeaklngTwo = (ImageButton) findViewById(R.id.spklngButton2);
		btnSpeaklngTwo.setOnClickListener(new View.OnClickListener() {

			@Override
			public void onClick(View v) {
				Intent intent = new Intent(
						RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
		      intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL,
						new Locale("spa", "ESP"));
				try {
					startActivityForResult(intent, REQUEST_OK);
				} catch (ActivityNotFoundException a) {
					Toast t = Toast.makeText(getApplicationContext(),
							"Ops! Your device doesn't support Speech to Text",
							Toast.LENGTH_SHORT);
					t.show();
					
				}
			}
		});

	}

	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		super.onActivityResult(requestCode, resultCode, data);
		
		switch (requestCode) {
		case REQUEST_OK: {
			if (requestCode==REQUEST_OK  && resultCode==RESULT_OK) {

				ArrayList<String> text = data
						.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);

				try {
					if (data.getCharSequenceExtra(
							RecognizerIntent.EXTRA_LANGUAGE_MODEL).toString() == "en-US") {
						addChatItem(text.get(0).toString(), Language.ENGLISH,
								Language.SPANISH);
					} else {
						addChatItem(text.get(0).toString(), Language.SPANISH,
								Language.ENGLISH);
					}
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

			}
			break;
		}

		}
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		getMenuInflater().inflate(R.menu.activity_main, menu);
		return true;
	}

	@Override
	public void onInit(int status) {

		if (status == TextToSpeech.SUCCESS) {

			int result = textToSpeech.setLanguage(Locale.US);

			if (result == TextToSpeech.LANG_MISSING_DATA
					|| result == TextToSpeech.LANG_NOT_SUPPORTED) {
				Log.e("TTS", "This Language is not supported");
			}
		} else {
			Log.e("TTS", "Initilization Failed!");
		}
	}

	@Override
	public void onDestroy() {
		if (textToSpeech != null) {
			textToSpeech.stop();
			textToSpeech.shutdown();
		}
		super.onDestroy();
	}

	private void speakOut(String speakText, String lng) {

		Locale srcLocale = null;
		if (lng == "spa" || lng == "es") {
			srcLocale = new Locale("spa", "ESP");
		} else if (lng == "en") {
			srcLocale = Locale.US;
		}

		int result = textToSpeech.setLanguage(srcLocale);

		if (result == TextToSpeech.LANG_MISSING_DATA
				|| result == TextToSpeech.LANG_NOT_SUPPORTED) {
			Log.e("TTS", "This Language is not supported");
		} else {
			textToSpeech.speak(speakText, TextToSpeech.QUEUE_FLUSH, null);

		}

	}

	private void addChatItem(final String recognizedText,
			final Language languageFrom, final Language languageTo)
			throws Exception {
		TextView spokenTextFrom;
		final TextView spokenTextTo;
		ImageButton speakOut;
		LinearLayout mainView = (LinearLayout) findViewById(R.id.chatWindow);

		LinearLayout newlayout = new LinearLayout(this);
		newlayout.setOrientation(1);

		LinearLayout fromLngLayout = new LinearLayout(this);
		fromLngLayout.setOrientation(0);
		ImageButton fromFlag = new ImageButton(this);
		fromFlag.setLayoutParams(new LayoutParams(LayoutParams.WRAP_CONTENT,
				android.app.ActionBar.LayoutParams.WRAP_CONTENT));
		if(languageFrom==Language.ENGLISH)
		{
			fromFlag.setImageResource(R.drawable.us);
			
		}else
		{

			fromFlag.setImageResource(R.drawable.es);
		}
		fromLngLayout.addView(fromFlag);
		
		// First add a text label with Recognized Text in From Language
		spokenTextFrom = new TextView(this);
		spokenTextFrom.setText(recognizedText);
		spokenTextFrom.setLayoutParams(new LayoutParams(
				LayoutParams.WRAP_CONTENT, 40));
		
		fromLngLayout.addView(spokenTextFrom);
		newlayout.addView(fromLngLayout);
		// Second Add the text label with Recognized Text in To Language
		LinearLayout toLngLayout = new LinearLayout(this);
		toLngLayout.setOrientation(0);
		
		ImageButton toFlag = new ImageButton(this);
		toFlag.setLayoutParams(new LayoutParams(LayoutParams.WRAP_CONTENT,
				android.app.ActionBar.LayoutParams.WRAP_CONTENT));
		
		if(languageTo==Language.ENGLISH)
		{
			toFlag.setImageResource(R.drawable.us);
			
		}else
		{

			toFlag.setImageResource(R.drawable.es);
		}
		toLngLayout.addView(toFlag);
		
		
		spokenTextTo = new TextView(this);
		// final String translatedText = translate(recognizedText, languageFrom,
		// languageTo);
		class TranslaterTask extends AsyncTask<Void, Void, Void> {
			String translatedText = "";

			@Override
			protected Void doInBackground(Void... params) {
				// TODO Auto-generated method stub
				try {
					translatedText = translate(recognizedText, languageFrom,
							languageTo);
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
					translatedText = e.toString();
				}
				return null;
			}

			@Override
			protected void onPostExecute(Void result) {
				spokenTextTo.setText(translatedText);
				super.onPostExecute(result);

				System.out.println(result);
			}

		}
		new TranslaterTask().execute();
		// spokenTextTo.setText(translatedText);

		spokenTextTo.setLayoutParams(new LayoutParams(
				LayoutParams.WRAP_CONTENT, 40));
		toLngLayout.addView(spokenTextTo);
		newlayout.addView(toLngLayout);

		speakOut = new ImageButton(this);
		speakOut.setLayoutParams(new LayoutParams(LayoutParams.WRAP_CONTENT,
				android.app.ActionBar.LayoutParams.WRAP_CONTENT));
		speakOut.setImageResource(R.drawable.speak);

		// speakOut.setLeft(left)
		speakOut.setOnClickListener(new View.OnClickListener() {

			@Override
			public void onClick(View v) {
				speakOut(spokenTextTo.getText().toString(),
						languageTo.toString());
			}
		});
		newlayout.addView(speakOut);

		mainView.addView(newlayout);

	}

	public String translate(String text, Language languageFrom,
			Language languageTo) throws Exception {
		Translate.setClientId("ugupta03"); // Change this
		Translate
				.setClientSecret("3wOWvc4bzzdWOiD7ThKJd1Seh/HeUzyrnkF0CnwpHdA="); // change

		String translatedText = "";

		translatedText = Translate.execute(text, languageFrom, languageTo);
		System.out.println(translatedText);
		return translatedText;
	}

}
